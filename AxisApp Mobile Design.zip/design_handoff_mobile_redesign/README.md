# Handoff: Axis Mobile Redesign (rounded, light + dark, 8 color presets)

## Overview
A restyle of Axis's Phase-1 debt-tracker flow: rounded corners, a calm/muted accent
palette, Manrope typography, full dark-theme parity, and — matching the "preset
palettes" idea already scoped in `SCOPE.md`'s Theming section — 8 selectable accent
presets (Indigo, Green, Red, Purple, Pink, Yellow, Orange, Dark Blue). This replaces
the current dark-only blue/amber look defined in `Resources/Styles/{Colors,Tokens,
Styles}.xaml`.

## About the design files
The bundled file (`AxisApp Screens (Rounded).dc.html`) is an **HTML design
reference** — a static prototype showing exact look, spacing, and copy. It is not
code to port line-for-line. The task is to **recreate this UI in MAUI XAML**,
using the project's existing MVVM/Shell architecture (`Pages/*.xaml` +
`ViewModels/*.cs`, styles from `Resources/Styles/`), updating the four token
files rather than hardcoding values in views (same rule the codebase already
follows).

## Fidelity
**High-fidelity.** Colors, radii, spacing, and copy below are final values — reproduce
them pixel-for-pixel where MAUI's layout model allows.

## Design tokens

### Radius (replaces `Tokens.xaml`'s `Radius*`/`Shape*` scale)
| Token | Old value | New value |
|---|---|---|
| Control (buttons, inputs, chips) | 8 | **10** |
| Card | 12 | **16** |
| Large (empty-state icon tile, dialogs) | — | **22** |
| Pill (segmented control, tags, FAB) | 999 | 999 (unchanged) |
| Avatars | square, `RadiusControl` | **circular (999)** — a deliberate change from the previous square-avatar look |

### Typography
Replace Archivo with **Manrope** (weights 500/600/700/800) — geometric, rounded
terminals, not yet embedded. Download `.ttf` files from Google Fonts and add to
`Resources/Fonts/`, register in `MauiProgram.cs` (`.ConfigureFonts(...)`) the same
way the current font is (or isn't) registered. Type ramp (sizes) is unchanged from
`Tokens.xaml` — only the family/weight changes: headings and amounts use 800,
labels/section headers use 700, body 600.

### Shadows
| Token | Light | Dark |
|---|---|---|
| `ShadowSm` | `0 1px 3px rgba(30,35,40,.07)` | `0 1px 3px rgba(0,0,0,.45)` |
| `ShadowMd` | `0 6px 18px rgba(30,35,40,.09)` | `0 8px 20px rgba(0,0,0,.5)` |
| `ShadowLg` | `0 18px 40px rgba(30,35,40,.16)` | `0 22px 48px rgba(0,0,0,.6)` |

### Base colors (shared across all 8 presets — only the accent group changes per preset)
| Role | Light | Dark |
|---|---|---|
| Background | `#F6F5F2` | `#16181C` |
| Surface / Card | `#FFFFFF` | `#1E2126` / `#262A31` |
| Text primary | `#1E2328` | `#F1F2F4` |
| Text secondary | `#6B7280` | `#A2A7AF` |
| Text tertiary / disabled | `#9AA1AC` | `#6E747C` |
| Divider / border | `#E7E3DD` / `#DAD5CD` | `#323740` / `#3A3F48` |
| Positive (owed to you, settle-up credit) | `#4F9E76` on `#E8F3EC` tint | `#7FC49B` on `#1E3226` tint |
| Negative (you owe) | `#C4694B` on `#FBEDE7` tint | `#E08B6C` on `#3A2620` tint |

Positive/negative are **semantic, not brand** — they stay the same across every
accent preset.

### Accent presets — implements `SCOPE.md`'s "Theming (discussed, not planned)" section
Exactly the mechanism that section describes: one `Colors.xaml`-shaped resource per
preset, switched via `{DynamicResource}` + a `ThemeService`, persisted with
`Preferences`. These are the 8 presets' `Accent` / `AccentHover` / `AccentPressed` /
`AccentTint` values, light then dark:

| Preset | Light accent / hover / pressed / tint | Dark accent / hover / pressed / tint |
|---|---|---|
| Indigo (default) | `#5B72D6` `#4A5FC0` `#3C4EA3` `#ECEFFB` | `#8C9DF2` `#A2B0F4` `#6E80D8` `#272B45` |
| Green | `#4C8F63` `#3F7A53` `#336447` `#E7F3EA` | `#7FBF95` `#99CDA9` `#63A67C` `#1E3226` |
| Red | `#C25450` `#AC4642` `#8F3733` `#FBEAE9` | `#E28F8B` `#E9A6A2` `#C86E69` `#3A2321` |
| Purple | `#7C5FBF` `#6B4FA8` `#573F8A` `#F1ECFB` | `#B39EE8` `#C3B2ED` `#9784CE` `#2C2640` |
| Pink | `#C15A87` `#A94A74` `#8D3B60` `#FBEAF1` | `#E599B7` `#EBADC5` `#CC7A9C` `#3A2430` |
| Yellow | `#A97A22` `#926819` `#785713` `#FBF0DD` | `#E0B564` `#E7C583` `#C89A48` `#3A2E14` |
| Orange | `#C36B3E` `#AC5931` `#8F4827` `#FBEEE5` | `#E2A278` `#E9B491` `#C8845C` `#3A2A1E` |
| Dark Blue | `#35507D` `#2A4066` `#213353` `#E7ECF3` | `#7C97C4` `#96AED4` `#6280AE` `#1E2A3A` |

**Implementation note**: unlike the rest of `Colors.xaml`, on the Yellow preset the
accent is deliberately darkened (vs. a "true" yellow) so white button text
(`TextOnAccent`) stays legible — don't lighten it back without also revisiting
`TextOnAccent` for that preset.

## Screens / views
Sample data used throughout: group **"Axis"** (Aitor — the signed-in viewer, Marc,
Paula, Gil) and group **"Cabin trip"** (Aitor, Paula).

### 1. Splash — `Pages/SplashPage.xaml` (exists, restyle only)
Centered column: "Axis" wordmark (800 weight, 40px), a 44×4px accent rounded bar,
"One shared ledger." (muted, 13px, 600), a 24px circular spinner (3px border,
accent top segment, rotating).

### 2. Login — `Pages/LoginPage.xaml` (exists, restyle only)
Top-left "Axis" wordmark (22px/800). Heading "Log in" (24px/800) + subhead "Track
shared expenses with your household." Email field, password field (both using the
new `.Input` style — 1.5px border, 10px radius, 13px/14px padding). Full-width
primary button "Log in". "OR" divider (two 1px rules + centered muted label).
Full-width secondary (outline) button "Create an account". Centered ghost link
"Forgot password?" in accent color.

### 3. Groups list — `Pages/GroupsPage.xaml` (exists, restyle only)
Header row: "Axis" wordmark flush left, circular avatar button (initial "A", dark
fill) flush right — tapping it opens the account-menu overlay (screen 9).
Section label "YOUR GROUPS" (11px/700, uppercase, tracked). Group cards (16px
radius, white/surface fill, `ShadowSm`): group name (16px/800), a row of small
22px circular member-initial avatars + "N members" caption, and on the right the
net balance — **positive** in `--positive` color with a "you're owed" pill tag,
**negative** in `--negative` color with a "you owe" pill tag. Bottom row: two
buttons side by side, "Join with code" (outline) and "New group" (primary, plus
icon) — `GroupsViewModel`'s existing `JoinGroupCommand` and group-creation flow.

### 3b. Groups list — empty state
Same header. Centered: a 64px circular accent-tinted icon tile (people icon),
"No groups yet" (19px/800), muted body copy, then stacked full-width buttons
"New group" (primary) / "Join with code" (outline).

### 4. Group detail — `Pages/GroupDetailPage.xaml` (exists, restyle only)
Header: back button, group name (flush left, 17px/800), overflow (⋮) button.
"BALANCES · PAIRWISE" label + a 2-option segmented control (Pairwise / Simplified)
— bound to the existing per-account/per-group `BalanceDisplayModePrefix` local
preference described in `CLAUDE.md`.
- **Pairwise rows**: 38px circular avatar, name (700/14px), "owes you"/"you owe"
  caption (muted/600/12px), amount (800/15px, positive/negative color), ghost
  "Settle" button → `GroupDetailViewModel.Settle(MemberBalanceItem)`.
- **Simplified mode**: a "Net position" summary card (kicker + large 28px/800
  amount + one-line explainer), then one or more "suggested transfer" rows tagged
  `suggested` (outline pill), plus a muted note when two other members settle
  between themselves without routing through the viewer.
"RECENT ACTIVITY" label + expense rows: 34px rounded category-icon tile
(accent-tinted bg, accent-colored icon), title (700/14px), "Paid by {name} ·
{date}" caption, amount right-aligned (700/14px). Floating circular accent FAB
(56px, plus icon, `ShadowLg`) bottom-right → `AddExpensePage`.

### 5. Add / edit expense — `Pages/AddExpensePage.xaml` (exists, restyle only)
Header: "Cancel" (left, ghost) / "Add expense" (center title) / "Save" (right,
accent, bold) — this page already doubles as edit mode via `?expenseId=`.
Description input. Large centered amount readout ("€" muted prefix + bold 34px
number) with a 2px bottom rule instead of a boxed input. "CATEGORY" label + a
horizontally wrapping row of category pills (outline when unselected, solid
accent fill when selected) for Groceries/Utilities/Transport/Entertainment/Travel.
"PAID BY" label + a row of circular avatars, selected one ringed in accent (2px
outline, 2px offset), others at 50% opacity. "SPLIT" label + Equally/Manually
segmented control. "SPLIT BETWEEN" checklist: avatar + name + per-person share
amount + a small rounded checkbox (filled accent square when included, outlined
and everything dimmed to 50% when excluded) — maps to the existing
`SplitCheckboxStyle` concept, just squircle instead of sharp-cornered. Full-width
primary "Save expense" button.

### 6. Settle up — new screen (not yet built; `GroupDetailViewModel.Settle` currently
has no dedicated page — decide whether to route there or keep it as a confirm
dialog)
Header: back + "Settle up" title. Centered: two 56px circular avatars (counterparty,
then "You") with a right-arrow between them, a large 40px/800 amount, a caption
("{Name} pays you" / "You pay {Name}"), a muted explainer line ("This records a
payment. It won't change any other balance in the group."), then a full-width
primary "Confirm settlement" button and a ghost "Cancel".

### 7. Join group — `Pages/JoinGroupPage.xaml` (exists, restyle only)
Header: back + "Join a group". "HAVE AN INVITE CODE?" label, monospace-styled
input (placeholder `AX7K-9QPL`), full-width primary "Join" button. "OR" divider.
"ADD A MEMBER BY NAME" label + search input + live match rows: a **phantom**
match shows a dashed-outline avatar, name, a `phantom` neutral tag, and a "Link"
outline button (`LinkExistingMemberCommand`); a **claimed** match shows a solid
avatar, name, and muted text "already on Axis — send the invite code" with no
action button. Footer italic note: "People without an account yet can still be
added by name."

### 8. New group — new dedicated screen (currently a native `DisplayPromptAsync`
per `SCOPE.md` — this design promotes it to a real page)
Header: back + "New group". "GROUP NAME" label + input (placeholder "e.g. Family,
Roommates"), muted helper text "You can invite members once the group is
created.", full-width primary "Create group" button, centered ghost "Cancel" link.

### 9. Account menu — overlay on Groups list (`GroupsPage`'s existing
`IsAccountMenuOpen` dropdown, restyled)
Same Groups-list header/body behind a dark scrim. A floating card (16px radius,
`ShadowLg`) anchored top-right under the avatar: email (13px/800) with a bottom
rule, a disabled "Profile" row (40% opacity, no action yet), a "Log out" row in
the negative/danger color (700 weight) → `GroupsViewModel.Logout`.

## Interactions & behavior
- Segmented controls, category pills, and the split checklist are static/native
  selection controls — no custom animation required, but give every interactive
  element the same themed hover/pressed treatment already established in
  `Styles.xaml`'s `VisualStateManager` pattern (scale 0.97 on press, accent-hover
  background on pointer-over).
- The Pairwise/Simplified toggle on Group Detail should persist per the existing
  `BalanceDisplayModePrefix` local preference — no new state needed, just re-skin.
  the two rendering branches already implemented in `GroupDetailViewModel`.
  The two branches described in Screen 4 above are the resulting visual states.
- FAB, Settle buttons, and Save buttons should trigger the same
  `[RelayCommand]`s already wired (`AddExpense`, `Settle`, `Save`, `JoinByCode`,
  `LinkExistingMemberCommand`, `Logout`) — this handoff changes appearance only,
  not the underlying flow, except where noted (new Settle-up and New-group pages).
- Empty state (screen 3b) should show whenever `GroupsViewModel`'s groups
  collection is empty — no new logic, just a view branch already implied by
  existing empty-collection handling (add one if it doesn't exist).

## State management
No new state beyond what's already in the ViewModels, plus:
- **Color preset**: a new `AppConstants.Preferences`-style key (e.g.
  `ColorPresetKey`), read at startup next to the existing `UserAppTheme =
  AppTheme.Dark` line in `App.xaml.cs`, applied via a `ThemeService` that swaps
  which `Colors.{Preset}.xaml` dictionary is merged into
  `Application.Current.Resources.MergedDictionaries` — exactly the mechanism
  `SCOPE.md` already scoped out. Note this handoff also **removes the "dark
  theme enforced globally" constraint** — light/dark now needs to be a user
  choice (or follow system), not a hardcoded `AppTheme.Dark`.
- **Dark mode**: same `DynamicResource` swap mechanism, a second axis independent
  of color preset (any of the 8 presets × light or dark = 16 total resource
  dictionary combinations, but the "accent-only" split above means you likely
  want two dictionaries per preset — `Colors.{Preset}.Light.xaml` /
  `Colors.{Preset}.Dark.xaml` — rather than 16 hand-written full files).

## Assets
No image assets. All icons in the prototype are inline Lucide-style outline SVGs
(2px stroke, round caps/joins) — recreate with a MAUI-compatible icon set (an
embedded icon font, `Microsoft.Maui.Graphics` custom drawables, or SVG-to-XAML
conversion) rather than raster images. Icons used: back arrow, more-vertical
(⋮), plus, log-out, user, users, shopping-cart, ticket, car, plane, arrow-right.

## Files
- `AxisApp Screens (Rounded).dc.html` — the full design reference (10 screens ×
  light/dark = 20 frames, plus the 8-preset color switcher).
